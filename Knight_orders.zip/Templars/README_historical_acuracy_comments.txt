The crosses should be on the heart, not big ones in middle of torso.

Same advice as hospitallers, probably too early for kettle helmets.

